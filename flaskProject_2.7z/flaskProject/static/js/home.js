let menuToggle = document.querySelector(".menuToggle");
let slideBar = document.querySelector(".slidebar");
let bgChangeToggle = document.querySelector(".toggle-btn");
let logo = document.querySelector(".logo");
let selectionLis = document.querySelectorAll("ul li");
let linkLis = document.querySelectorAll(".link");
let logoutBtn = document.getElementById("logout");
let personInfo = document.querySelector(".personInfo");
let horizontalBar = document.querySelector(".horizontalBar");
let bakcToTopToggle = document.querySelector(".backToTop");
let lockIcon = document.querySelector(".toggle-btn .icon ion-icon");
let changePasswd = document.getElementById("changePasswd");

//修改密码
changePasswd.addEventListener("click", () => {

});

//监听滚动，展示阴影
window.onscroll = () => {
    // console.log(document.documentElement.scrollTop);  
    // horizontalBar.style.boxShadow = document.documentElement.scrollTop ? 
    // slideBar.classList.contains("night") ? "0 16px 32px -16px rgba(255, 255, 255, 0.25), 0 0 0 1px rgba(255, 255, 255, 0.3)" : "0 16px 32px -16px rgba(0,0,0,.1), 0 0 0 1px rgba(0,0,0,.1)" 
    // : "";
}

bakcToTopToggle.onclick = (e) => {
    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
}

//移动按钮
menuToggle.addEventListener("mousedown", startDrag);

function startDrag(e) {
    e.preventDefault();

    let {width, height} = menuToggle.style;
    width = width.substring(0, width.indexOf("px"));
    height = height.substring(0, height.indexOf("px"));
    let { left, top } = menuToggle.getBoundingClientRect();
    let offsetX = e.clientX - left; //偏移
    let offsetY = e.clientY - top;

    function doDrag(e) {
        let x = e.clientX - offsetX;
        let y = e.clientY - offsetY;
        let {innerWidth: outerWidth, innerHeight: outerHeight} = window;
        menuToggle.style.left = x <= 0 ? "0px" : x >= outerWidth - width ? (outerWidth - width) + "px" : (x + "px");
        menuToggle.style.top = y <= 0 ? "0px" : y >= outerHeight - height ? (outerHeight - height) + "px" : (y + "px");
    }

    function stopDrag() {
        document.removeEventListener("mousemove", doDrag);
        document.removeEventListener("mouseup", stopDrag);
    }

    document.addEventListener("mousemove", doDrag);
    document.addEventListener("mouseup", stopDrag);
}

//退出登录
logoutBtn.onclick = () => {
    location.href = "/logout";
}

//切换侧边栏
menuToggle.onclick = () => {
    menuToggle.classList.toggle("active");
    slideBar.classList.toggle("active");
};

let menuList = document.querySelectorAll(".Menulist li");
function activeSelection() {
    menuList.forEach(menuItem => menuItem.classList.remove("active"));
    this.classList.add("active");
}

menuList.forEach(menuItem =>
    menuItem.addEventListener("click", activeSelection)
);

//背景切换
bgChangeToggle.addEventListener("click", () => {
    bgChangeToggle.classList.toggle("active");
    //console.dir(lockIcon);
    slideBar.classList.toggle("night");
    personInfo.classList.toggle("night");
    horizontalBar.classList.toggle("night");
    if (bgChangeToggle.classList.contains("active")) {
        lockIcon.setAttribute("name", "moon-outline");
        document.body.style.background = "#22242e";
        // horizontalBar.style.boxShadow = "0 16px 32px -16px rgba(255, 255, 255, 0.25), 0 0 0 1px rgba(255, 255, 255, 0.3)";
    } else {
        lockIcon.setAttribute("name", "sunny-outline");
        document.body.style.background = "#fff";
        // horizontalBar.style.boxShadow = "0 16px 32px -16px rgba(0,0,0,.1), 0 0 0 1px rgba(0,0,0,.1)";
    }
});

//选中链接
selectionLis.forEach(selection =>
    selection.addEventListener("click", () => {
        if (selection.classList.contains("active")) {
            document.documentElement.style.setProperty(
                "--logo-clr",
                selection.style.getPropertyValue("--bg")
            );
        }
    })
);

linkLis.forEach(link => link.addEventListener("click", () => {
    location.href = `/${link.id}/5/1`;
}));