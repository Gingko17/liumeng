let itemNum = 50; 
      let pageNum = 20;
      let pagination = document.querySelector(".pagination");
      let aLink = document.createElement("a");
      function clearStyle() {
        let aLinks = document.querySelectorAll("a");
        Array.from(aLinks).forEach((aLink) => aLink.classList.remove("active"));
      }

      for (let i = 0; i < pageNum; ++i) {
        let page = aLink.cloneNode(true);
        page.className = i === 0 ? "item active" : "item";
        page.innerText = i + 1;
        pagination.appendChild(page);
        page.addEventListener("click", () => {
          clearStyle();
          page.classList.add("active");
        });
      }

      let searchBtn = document.querySelector("")