import hashlib
import json
import os
import urllib.parse
from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from my_sqlite import *

app = Flask(__name__)

app.secret_key = "gingko forever."

tableTitlesCN = {
    "stu_id": "学号",
    "stu_name": "姓名",
    "stu_sex": "性别",
    "stu_age": "年龄",
    "stu_origin": "籍贯",
    "stu_profession": "专业",
}

def check_login():
    return "username" in session

def parse_special_char(string):
    return string.replace("%25", "%").replace("%23", "#").replace("%26", "&").replace("%3F", "?")

def process_data(form):
    data = dict(
        stu_id=form["stu_id"],
        stu_name=form["stu_name"],
        stu_sex=form["stu_sex"],
        stu_age=form["stu_age"],
        stu_origin=form["stu_origin"],
        stu_profession=form["stu_profession"],
    )
    return data

def get_page_rows(page_item_num, page_num):
    page_item_num = int(page_item_num)
    page_num = int(page_num)
    rows, tableTitles = exec_sql(
        f"select s.stu_id,  s.stu_name,  s.stu_sex, s.stu_age,  s.stu_origin,  p.profession_name as stu_profession from student_info s join profession_info p on s.stu_profession = p.profession_id limit {page_item_num} offset {page_item_num * (page_num - 1)}")
    for i in range(len(tableTitles)):
        tableTitles[i] = tableTitlesCN[tableTitles[i]]
    return rows, tableTitles


@app.route("/", methods=["GET"])
def home():
    if not check_login():
        return redirect(url_for("login"))
    return render_template("home.html",username = session["username"])


def getStudentCount():
    rows, _ = exec_sql("select * from student_info")
    return len(rows)


@app.route("/show/<page_item_num>/<page_num>", methods=["GET"])
def show_student_data(page_item_num, page_num):
    if not check_login():
        return redirect(url_for("login"))
    rows, tableTitles = get_page_rows(page_item_num, page_num)
    return render_template("show.html", rows=rows, tableTitles=tableTitles, page_num=page_num, page_item_num=page_item_num, totalNum=getStudentCount())

    
@app.route("/logout")
def logout():
    session.pop("username")
    return render_template(
        "login.html",
        msg="Successfully logout.",
        username="",
        password="",
    )

@app.route("/login", methods=["POST", "GET"])
def login():
    if request.method == "GET":
        return render_template("login.html")
    username = urllib.parse.unquote(request.form["user-name"])
    tmp_password = urllib.parse.unquote(request.form["user-password"])
    password = tmp_password.encode("utf-8")
    result, _ = exec_sql("select * from user_info where username = ? ", (username,))
    # PBKDF2 解密
    iterations = 100000
    if len(result) == 0:
        return render_template(
            "login.html",
            msg="Password or Username is error.",
            username=username,
            password=tmp_password,
        )
    hashed_password = result[0][1]
    salt = result[0][2]
    password = hashlib.pbkdf2_hmac("sha256", password, salt, iterations)
    if password == hashed_password:
        session["username"] = username
        return render_template(
            "login.html",
            msg="Successfully login.",
            username=username,
            password=tmp_password,
        )

    else:
        return render_template(
            "login.html",
            msg="Password or Username is error.",
            username=username,
            password=tmp_password,
        )


@app.route("/register", methods=["POST", "GET"])
def register():
    if request.method == "GET":
        return render_template("register.html")
    username = urllib.parse.unquote(request.form["user-name"])
    tmp_password = urllib.parse.unquote(request.form["user-password"])
    password = tmp_password.encode("utf-8")

    result, _ = exec_sql("select * from user_info where username = ? ", (username,))
    if len(result) != 0:
        return render_template(
            "register.html",
            msg="The username is already existed.",
            username=username,
            password=tmp_password,
        )

    # 使用 PBKDF2 进行密码加密
    salt = os.urandom(16)
    iterations = 100000
    hashed_password = hashlib.pbkdf2_hmac("sha256", password, salt, iterations)
    data = {"username": username, "password": hashed_password, "salt": salt}
    insert_data(data, "user_info")
    return render_template(
        "register.html",
        msg="Successfully register.",
        username=username,
        password=tmp_password,
    )

@app.route("/revise",methods=["POST","GET"])
def revise():
    if request.method =="GET":
        return render_template("revise.html")
    tmp_password = urllib.parse.unquote(request.form["current-password"])
    password = tmp_password.encode("utf-8")
    new_password = urllib.parse.unquote(request.form["user-password"])
    conf_password = urllib.parse.unquote(request.form["conf-password"])
    iterations = 100000
    username = session['username']
    result, _ = exec_sql("select * from user_info where username = ? ", (username,))
    
    if(len(new_password)>0 and len(conf_password)>0):
        salt = os.urandom(16)
        hashed_password = hashlib.pbkdf2_hmac("sha256", conf_password.encode("utf-8"), salt, iterations)
        print(hashed_password)
        data = {"username": username, "password": hashed_password, "salt": salt}
        update_data(data,"user_info")
        session.pop('username')
        return render_template(
            "revise.html",
            msg="Successful change.",
            curpassword =tmp_password,
            newpassword = new_password,
            confirmpassword = conf_password
        )
    else:
        truePassword = result[0][1]
        salt = result[0][2]
        inputPassword = hashlib.pbkdf2_hmac("sha256", password, salt, iterations)
        if truePassword!=inputPassword:
            return render_template(
                "revise.html",
                msg="Wrong password.",
                curpassword =tmp_password,
                newpassword = "",
                confirmpassword = ""
            )
        else:
            return render_template(
                "revise.html",
                msg="Correct password.",
                curpassword =tmp_password,
                newpassword = "",
                confirmpassword = ""
            )

@app.route("/add", methods=["GET", "POST"])
def add():  
    pros, _ = exec_sql("select * from profession_info")
    return render_template("submit_table.html", action="add", data="", pros=pros)

@app.route("/delete/<page_item_num>/<page_num>", methods=["GET"])
def delete_student_data(page_item_num, page_num):
    if not check_login():
        return redirect(url_for("login"))
    rows, tableTitles = get_page_rows(page_item_num, page_num)
    return render_template("delete.html", rows=rows, tableTitles=tableTitles, page_num=page_num, page_item_num=page_item_num, totalNum=getStudentCount())

@app.route("/change/<page_item_num>/<page_num>", methods=["GET"])
def change_student_data(page_item_num, page_num):
    if not check_login():
        return redirect(url_for("login"))
    rows, tableTitles = get_page_rows(page_item_num, page_num)
    return render_template("change.html", rows=rows, tableTitles=tableTitles, page_num=page_num, page_item_num=page_item_num, totalNum=getStudentCount())

@app.route("/delete/<_id>", methods=["GET"])
def delete(_id):
    delete_data_by_id("stu_id", _id, "student_info")
    return redirect(url_for("show_student_data"))


@app.route("/delete_selected/<ids>", methods=["GET"])
def delete_selected(ids):
    for _id in ids.split(","):
        delete_data_by_id("stu_id", _id, "student_info")
    return redirect(url_for("show_student_data"))


@app.route("/update/<_id>", methods=["GET"])
def update(_id):
    pros, _ = exec_sql("select * from profession_info")
    result, fields = exec_sql("select * from student_info where stu_id=?" % _id)
    data = {fields[i]: result[0][i] for i in range(len(fields))}
    return render_template(
        "submit_table.html", action="update", data=json.dumps(data), pros=pros
    )


@app.route("/save/<action>", methods=["POST"])
def save(action):
    data = process_data(request.form)
    print(data)
    pros, _ = exec_sql("select * from profession_info")
    if action == "add":
        result,_ =exec_sql("select * from student_info where stu_id = ?" ,(data['stu_id'],))
        if len(result)!=0: 
            data['msg']="该学号已存在"
            return render_template("submit_table.html",data = data ,pros = pros,action=action)
        else:
            for achar in data['stu_name']:
                if not '\u4e00' <= achar <= '\u9fff':
                    data["msg"] = "姓名中不能包含非中文字符"
                    return render_template("submit_table.html",data = data,pros=pros,action=action)
            insert_data(data, "student_info")
            
        data["msg"] = "添加成功"
        return render_template("submit_table.html",data = data,pros=pros,action=action)
    else:
        update_data(data, "student_info")
        return redirect(url_for("show_student_data"))


if __name__ == "__main__":
    app.run(debug=True)
