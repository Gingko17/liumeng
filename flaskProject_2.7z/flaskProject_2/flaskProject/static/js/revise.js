let container = document.querySelector('.container');
let newPasswordInput = document.getElementById('newPassword');
let currentPasswordInput = document.getElementById('currentPassword');
var pwdCfInput = document.getElementById("confPassword");
let eyesIcon1 = document.getElementById('visibilityIcon1');
let eyesIcon2 = document.getElementById('visibilityIcon2');
let eyesIcon3 = document.getElementById('visibilityIcon3');
let form = document.getElementById("reviseForm");
let formContainer = document.getElementById("formContainer");
let row = document.querySelector(".row");
let passwordRuleList = document.querySelectorAll(".passwordRule");
let hiddenButton = document.getElementById("hiddenButton")
let reviseButton = document.getElementById("reviseButton")
let msg = document.getElementById("msg").innerText;
// window.history.replaceState(null, null, window.location.href);
function confirm() {
    if (currentPasswordInput.value == 0) {
        alertError("Input your current password!", () => { currentPasswordInput.focus() });
        return;
    }
    form.submit();
}
function change() {
    var password = newPasswordInput.value;
    for (var e of passwordRuleList) {
        if (!(e.classList.contains("is_valid"))) {
            alertError("Incorrect password!", () => { newPasswordInput.focus() }, false);
            return;
        }
    }
    if (password !== pwdCfInput.value) {
        alertError("Password confirmation error!", () => { pwdCfInput.focus() });
        return;
    }
    form.submit();
}

var passwordNumberReg = /^.*\d+.*$/;
var passwordLengthReg = /^.{6,20}$/
var passwordUppercaseReg = /^.*[A-Z]+.*$/;
var passwordNoSpaceReg = /^\S+$/;
var passwordSpecialCharReg = /[@!#$%^&*()=+;:"-]+/;
newPasswordInput.onkeyup = function () {
    password = newPasswordInput.value;
    if (passwordLengthReg.test(password)) {
        passwordRuleList[0].classList.add("is_valid");
    } else if (passwordRuleList[0].classList.contains("is_valid")) {
        passwordRuleList[0].classList.remove("is_valid");
    }

    if (passwordNumberReg.test(password)) {
        passwordRuleList[1].classList.add("is_valid");
    } else if (passwordRuleList[1].classList.contains("is_valid")) {
        passwordRuleList[1].classList.remove("is_valid");
    }

    if (passwordUppercaseReg.test(password)) {
        passwordRuleList[2].classList.add("is_valid");
    } else if (passwordRuleList[2].classList.contains("is_valid")) {
        passwordRuleList[2].classList.remove("is_valid");
    }

    if (passwordSpecialCharReg.test(password)) {
        passwordRuleList[3].classList.add("is_valid");
    } else if (passwordRuleList[3].classList.contains("is_valid")) {
        passwordRuleList[3].classList.remove("is_valid");
    }

    if (passwordNoSpaceReg.test(password)) {
        passwordRuleList[4].classList.add("is_valid");
    } else if (passwordRuleList[4].classList.contains("is_valid")) {
        passwordRuleList[4].classList.remove("is_valid");
    }
}

newPasswordInput.onfocus = function () {
    var newWidth = 400 + 360;
    if (window.innerWidth > newWidth) {
        form.style.borderRight = "2px solid skyblue";
        container.style.width = newWidth + "px"
        document.getElementById("passwordHint").style.opacity = "1";
    }
    showEyesIcon(newPasswordInput);
}

newPasswordInput.onblur = function () {
    form.style.borderRight = "0 solid skyblue";
    document.getElementById("passwordHint").style.opacity = "0";
    container.style.width = "400px";
    hideEyesIcon(newPasswordInput)
}

currentPasswordInput.onfocus = function () {
    showEyesIcon(currentPasswordInput);

}
currentPasswordInput.onblur = function () {
    form.style.borderRight = "0 solid skyblue";
    hideEyesIcon(currentPasswordInput)
}


pwdCfInput.onfocus = function () {
    showEyesIcon(pwdCfInput);
    form.style.borderRight = "0 solid skyblue";
}
pwdCfInput.onblur = function () {
    hideEyesIcon(pwdCfInput);
}

function setup(msg) {
    currentPasswordInput.addEventListener('keyup', function (event) {
        if (event.key === 'Enter')
            hiddenButton.click();
    });
    pwdCfInput.addEventListener('keyup', function (event) {
        if (event.key === 'Enter')
            reviseButton.click();
    });
    eyesIcon1.addEventListener('mousedown', function (event) {
        event.preventDefault();
        togglePasswordVisibility(newPasswordInput);
        newPasswordInput.focus();
    });
    eyesIcon2.addEventListener('mousedown', function (event) {
        event.preventDefault();
        togglePasswordVisibility(pwdCfInput);
        pwdCfInput.focus();
    });
    eyesIcon3.addEventListener('mousedown', function (event) {
        event.preventDefault();
        togglePasswordVisibility(currentPasswordInput);
        currentPasswordInput.focus();
    });

    let string = "Change yourself!";
    for (let i = 0; i < string.length; ++i)
        setTimeout(() => {
            row.textContent += string[i];
        }, msg ? 0 : 70 * i);
    setTimeout(() => {
        // row.style.display = "none";
        formContainer.style.display = "flex";
        if (msg !== "Correct password.")
            container.style.height = "240px";
        //, (string.length + 1) * 0); //调试使用
    }, msg ? 0 : (string.length + 1) * 70);
}

function showEyesIcon(e) {
    if (e.id === "newPassword")
        eyesIcon1.style.display = 'inline-block';
    else if (e.id === "confPassword")
        eyesIcon2.style.display = 'inline-block';
    else
        eyesIcon3.style.display = 'inline-block';
}

function hideEyesIcon(e) {
    if (e.id === "newPassword")
        eyesIcon1.style.display = 'none';
    else if (e.id === "confPassword")
        eyesIcon2.style.display = 'none';
    else
        eyesIcon3.style.display = 'none';
}

function togglePasswordVisibility(e) {
    if (e.id === "newPassword")
        if (newPasswordInput.type === 'password') {
            newPasswordInput.type = 'text';
            eyesIcon1.className = 'iconfont icon-eyes';
        } else {
            newPasswordInput.type = 'password';
            eyesIcon1.className = 'iconfont icon-eyes-closed';
        }
    else if (e.id === "confPassword") {
        if (pwdCfInput.type === 'password') {
            pwdCfInput.type = 'text';
            eyesIcon2.className = 'iconfont icon-eyes';
        } else {
            pwdCfInput.type = 'password';
            eyesIcon2.className = 'iconfont icon-eyes-closed';
        }
    }
    else {
        if (currentPasswordInput.type === 'password') {
            currentPasswordInput.type = 'text';
            eyesIcon3.className = 'iconfont icon-eyes';
        } else {
            currentPasswordInput.type = 'password';
            eyesIcon3.className = 'iconfont icon-eyes-closed';
        }

    }
}

window.onload = () => {
    setup(msg)
    if (msg == "Correct password.") {
        var newheight = 149.6 + 258
        container.style.height = newheight + "px";
        document.getElementById("hiddenRow1").style.visibility = "visible";
        document.getElementById("hiddenRow2").style.visibility = "visible";
        document.getElementById("hiddenRow1").style.opacity = "1";
        document.getElementById("hiddenRow2").style.opacity = "1";
        document.getElementById("hiddenButton").style.display = "none";
    }
    if (msg == "Wrong password.") {
        alertError(msg, null)
        return;
    }
    if (msg == "Successful change.") {
        alertSuccess(msg, ()=>{location.href = "/login"});
    }
}
window.onunload  = function(){
    msg="";
}