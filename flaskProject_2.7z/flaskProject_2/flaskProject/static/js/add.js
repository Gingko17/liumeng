// let dd = document.querySelector(".item").innerText
//     if (action === "add") {
//         document.title = "更改数据";
//         let form = document.getElementById("form");
//         let data = JSON.parse('{{ data| safe }}');
//         Object.keys(data).forEach(key => {
//             form[key].value = data[key];
//             if (key === "stu_id")
//                 form[key].readOnly = true;
//             if (key === "stu_sex") {
//                 document.querySelectorAll('input[name="stu_sex"]').forEach(radio => {
//                     if (radio.value === data[key])
//                         radio.checked = true;
//                 });
//             }
//         });
//     }
let useridInput = document.getElementById("userId");
let usernameInput = document.getElementById("userName");
let userSex = document.querySelectorAll("input[type='radio']");
let userAgeInput = document.getElementById("userAge");
let userOriginInput = document.getElementById("userOrigin");
let userProfession = document.getElementById("userProfession");
let data = Array.from(document.querySelectorAll(".item"));
window.onload = () => {
    let msg = data[6].innerText;
    if (msg !== "添加成功" && msg) {
        alertError(msg, null);
        console.log(data);
        useridInput.value =  data[0].innerText
        usernameInput.value = data[1].innerText;
        console.log(data[2].innerText);
        userSex.forEach(sex => sex.value === data[2].innerText ? sex.checked = "true" : undefined);
        userAgeInput.value = data[3].innerText;
        userOriginInput.value = data[4].innerText;
        userProfession.value = data[5].innerText;
    }
    else if(!msg) return;
    else
        alertSuccess(msg, () => {
            location.href = '/show/10/1'
        })
}
