function alertConfirm(title, callback) {
    Swal.fire({
        title: title,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: '确定',
        cancelButtonText: '取消'
    }).then((result) => {
        if (result.isConfirmed)
            callback && callback();
    });
}
function alertError(msg, callback, timerStatus = 1800) {
    Swal.fire({
        toast: true,
        icon: 'error',
        title: msg,
        showCancelButton: false,
        showConfirmButton: false,
        buttons: false,
        timer: timerStatus
    }).then((result) => {
        callback && callback();
    });
}

function alertSuccess(msg, callback, timerStatus = 1800) {
    Swal.fire({
        toast: true,
        icon: 'success',
        title: msg,
        showCancelButton: false,
        showConfirmButton: false,
        buttons: false,
        timer: timerStatus,
    }).then((result) => {
        callback && callback();
    });
}

function parseParams(obj) {
    let formatObj = obj.replace(/\%/g, "%25")
    formatObj = formatObj.replace(/\#/g, "%23")
    formatObj = formatObj.replace(/\&/g, "%26")
    formatObj = formatObj.replace(/\?/g, "%3F")
    return formatObj;
}
