let container = document.querySelector('.container');
let passwordInput = document.getElementById('userPassword');
let usernameInput = document.getElementById('userName');
var pwdCfInput = document.getElementById("confPassword");
let eyesIcon1 = document.getElementById('visibilityIcon1');
let eyesIcon2 = document.getElementById('visibilityIcon2');
let form = document.getElementById("registerForm");
let formContainer = document.getElementById("formContainer");
let registerContainer = document.getElementById("registerForm");
let registerButton = document.querySelector(".registerButton");
let row = document.querySelector(".row");
let hintLabel = document.getElementById("registerHint");//提示label
let passwordRuleList = document.querySelectorAll(".passwordRule");
let usernameRuleList = document.querySelectorAll(".userNameRule");

function register() {
    var username = usernameInput.value;
    var password = passwordInput.value;
    registerContainer.style.borderRight = "0 solid skyblue";
    for (var e of usernameRuleList) {
        if (!(e.classList.contains("is_valid"))) {
            alertError("Incorrect username!", () => { usernameInput.focus() });
            return;
        }
    }
    for (var e of passwordRuleList) {
        if (!(e.classList.contains("is_valid"))) {
            alertError("Incorrect password!", () => { passwordInput.focus() });
            return;
        }
    }
    if (password !== pwdCfInput.value) {
        alertError("Password confirmation error!", () => { pwdCfInput.focus() });
        return;
    }
    form.submit()
}
/*
    username should :
    6-16 Characters
    be unique
*/
var usernameLengthReg = /^.{6,16}$/;
usernameInput.onkeyup = function () {
    var username = usernameInput.value;
    if (usernameLengthReg.test(username)) {
        usernameRuleList[0].classList.add("is_valid");
    } else if (usernameRuleList[0].classList.contains("is_valid")) {
        usernameRuleList[0].classList.remove("is_valid")
    }
}

usernameInput.onfocus = function () {
    var newWidth = 400 + 240;
    if (window.innerWidth > newWidth) {
        registerContainer.style.borderRight = "2px solid skyblue";
        container.style.width = newWidth + "px"
        document.getElementById("userNameHint").style.opacity = "1";
    }
}


usernameInput.onblur = function () {
    registerContainer.style.borderRight = "0 solid skyblue";
    document.getElementById("userNameHint").style.opacity = "0";
    container.style.width = "400px";
}


// async function duplicateTest(name_to_be_checked) {
//     axios.post(`/checker?username=${encodeURIComponent(JSON.stringify(name_to_be_checked))}`)
//         .then(response => {
//             if (response.data.status !== "400") {
//                 usernameRuleList[1].classList.add("is_valid");
//             } else if (usernameRuleList[1].classList.contains("is_valid")) {
//                 usernameRuleList[1].classList.remove("is_valid")
//             }
//         })
//         .catch(error => {
//             alertError(error, null);
//         });
// }

/*
    password should:
    6-20 Characters
    Contains Number
    Contains Uppercase
    Contains Special Character
    Don't contains white space characters
*/
var passwordNumberReg = /^.*\d+.*$/;
var passwordLengthReg = /^.{6,20}$/
var passwordUppercaseReg = /^.*[A-Z]+.*$/;
var passwordNoSpaceReg = /^\S+$/;
var passwordSpecialCharReg = /[@!#$%^&*()=+;:"-]+/;
passwordInput.onkeyup = function () {
    password = passwordInput.value;
    if (passwordLengthReg.test(password)) {
        passwordRuleList[0].classList.add("is_valid");
    } else if (passwordRuleList[0].classList.contains("is_valid")) {
        passwordRuleList[0].classList.remove("is_valid");
    }

    if (passwordNumberReg.test(password)) {
        passwordRuleList[1].classList.add("is_valid");
    } else if (passwordRuleList[1].classList.contains("is_valid")) {
        passwordRuleList[1].classList.remove("is_valid");
    }

    if (passwordUppercaseReg.test(password)) {
        passwordRuleList[2].classList.add("is_valid");
    } else if (passwordRuleList[2].classList.contains("is_valid")) {
        passwordRuleList[2].classList.remove("is_valid");
    }

    if (passwordSpecialCharReg.test(password)) {
        passwordRuleList[3].classList.add("is_valid");
    } else if (passwordRuleList[3].classList.contains("is_valid")) {
        passwordRuleList[3].classList.remove("is_valid");
    }

    if (passwordNoSpaceReg.test(password)) {
        passwordRuleList[4].classList.add("is_valid");
    } else if (passwordRuleList[4].classList.contains("is_valid")) {
        passwordRuleList[4].classList.remove("is_valid");
    }
}

passwordInput.onfocus = function () {
    var newWidth = 400 + 360;
    if (window.innerWidth > newWidth) {
        registerContainer.style.borderRight = "2px solid skyblue";
        container.style.width = newWidth + "px"
        document.getElementById("passwordHint").style.opacity = "1";
    }
    showEyesIcon(passwordInput);
}

passwordInput.onblur = function () {
    registerContainer.style.borderRight = "0 solid skyblue";
    document.getElementById("passwordHint").style.opacity = "0";
    container.style.width = "400px";
    hideEyesIcon(passwordInput)
}

pwdCfInput.onfocus = function () {
    showEyesIcon(pwdCfInput);
    registerContainer.style.borderRight = "0 solid skyblue";
}
pwdCfInput.onblur = function () {
    hideEyesIcon(pwdCfInput);
}


window.onload = () => {
    const msg = document.getElementById("msg").innerText;
    setup(msg)
    if (msg === "Successfully register.")
        alertSuccess(msg, () => {
            location.href = "/login";
        });
    if (msg === "The username is already existed.")
        alertError(msg, null);
}


function setup(msg) {
    form.addEventListener('keyup', function (event) {
        if (event.key === 'Enter')
            registerButton.click();
    });
    eyesIcon1.addEventListener('mousedown', function (event) {
        event.preventDefault();
        togglePasswordVisibility(passwordInput);
        passwordInput.focus();
    });
    eyesIcon2.addEventListener('mousedown', function (event) {
        event.preventDefault();
        togglePasswordVisibility(pwdCfInput);
        pwdCfInput.focus();
    });

    let string = "Nice to meet you.";
    for (let i = 0; i < string.length; ++i)
        setTimeout(() => {
            console.log(i);
            row.textContent += string[i];
        }, msg ? 0 : 70 * i);
    setTimeout(() => {
        // row.style.display = "none";
        formContainer.style.display = "flex";
        //, (string.length + 1) * 0); //调试使用
    }, msg ? 0 : (string.length + 1) * 70);
}

function showEyesIcon(e) {
    if (e.id === "userPassword")
        eyesIcon1.style.display = 'inline-block';
    else
        eyesIcon2.style.display = 'inline-block';
}

function hideEyesIcon(e) {
    if (e.id === "userPassword")
        eyesIcon1.style.display = 'none';
    else
        eyesIcon2.style.display = 'none';
}

function togglePasswordVisibility(e) {
    if (e.id === "userPassword")
        if (passwordInput.type === 'password') {
            passwordInput.type = 'text';
            eyesIcon1.className = 'iconfont icon-eyes';
        } else {
            passwordInput.type = 'password';
            eyesIcon1.className = 'iconfont icon-eyes-closed';
        }
    else {
        if (pwdCfInput.type === 'password') {
            pwdCfInput.type = 'text';
            eyesIcon2.className = 'iconfont icon-eyes';
        } else {
            pwdCfInput.type = 'password';
            eyesIcon2.className = 'iconfont icon-eyes-closed';
        }

    }
}



