let passwordInput = document.getElementById('userPassword');
let usernameInput = document.getElementById('userName');
let eyesIcon = document.getElementById('visibilityIcon');
let form = document.getElementById("loginForm");
let row = document.querySelector(".row");
let canvas = document.getElementById("canvas");
let context = canvas.getContext("2d");
let loginInButton = document.querySelector(".loginInButton");
let modal = document.getElementById("modal");
const codeItem = document.querySelectorAll('.code-item')
const codeInput = document.querySelector('.code-input')
let num //定义容器接收验证码

const showNum = () => {
    const curVal = codeInput.value;
    Array.from(codeItem).map((item, index) => {
        curVal[index] ?
            item.innerText = curVal[index] :
            item.innerText = ''
    });
}

const cutAct = (type) => {
    const valLength = codeInput.value.length
    Array.from(codeItem).map(item => {
        item.className = 'code-item'
    })
    if (type === 'focus') {
        codeItem[valLength === 4 ? valLength - 1 : valLength].className = 'code-item active'
    }
    if (valLength === 4)
        codeSubmit();
}

codeInput.addEventListener('focus', () => {
    cutAct('focus')
})

codeInput.addEventListener('blur', () => {
    cutAct('blur')
})

codeInput.addEventListener("keydown", function (event) {
    const keys = ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"]
    keys.forEach(function (key) {
        if (event.key === key)
            event.preventDefault();
    });
});

codeInput.addEventListener('input', () => {
    showNum()
    cutAct('focus')
});

window.onload = () => {
    let msg = document.getElementById("msg").innerText;
    setup(msg)
    if (msg === "Successfully login.")
        alertSuccess(msg, () => {
            let tmpValue = parseParams(usernameInput.value);
            location.href = `/${tmpValue}`;
        });
    if (msg === "Password or Username is error.")
        alertError(msg, null);
    if (msg === "Successfully logout.")
        alertSuccess(msg, null);
}
function setup(msg) {
    form.addEventListener('keyup', function (event) {
        if (event.key === 'Enter')
            loginInButton.click();
    });
    eyesIcon.addEventListener('mousedown', function (event) {
        event.preventDefault();
        togglePasswordVisibility();
        passwordInput.focus();
    });
    let string = "Welcome to Gingko's hub!\nLet's begin the adventure.";
    for (let i = 0; i < string.length; ++i)
        setTimeout(() => {
            row.textContent += string[i];
        }, msg ? 0 : 50 * i);
    setTimeout(() => {
        form.style.display = "block";
        //, (string.length + 1) * 0); //调试使用
    }, msg ? 0 : (string.length + 1) * 50);
}

function showEyesIcon() {
    eyesIcon.style.display = 'inline-block';
}

function hideEyesIcon() {
    eyesIcon.style.display = 'none';
}

function togglePasswordVisibility() {
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        eyesIcon.className = 'iconfont  icon-eyes';
    } else {
        passwordInput.type = 'password';
        eyesIcon.className = 'iconfont  icon-eyes-closed';
    }
}

function loginIn() {
    let password = passwordInput.value.trim();
    let username = usernameInput.value.trim();
    if (!username) {
        alertError("Please input username.", null);
        return;
    }
    if (!password) {
        alertError("Please input password.", null);
        return;
    }
    modal.classList.add("target");
    codeInput.focus();
}



function outsideTrigger() {
    modal.classList.remove("target");
}


draw();
canvas.onclick = function () {
    context.clearRect(0, 0, 120, 40);//在给定的矩形内清除指定的像素
    draw();
    codeInput.focus();
}

function getColor() {
    let r, g, b;
    do {
        r = Math.floor(Math.random() * 256);
        g = Math.floor(Math.random() * 256);
        b = Math.floor(Math.random() * 256);
    } while (r + g + b > 500); // 限制颜色通道之和的值

    return "rgb(" + r + "," + g + "," + b + ")";
}

function draw() {
    context.strokeRect(0, 0, 120, 40);
    let aCode = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f"];
    let arr = [] //定义一个数组用来接收产生的随机数
    for (let i = 0; i < 4; i++) {
        let x = 20 + i * 20;//每个字母之间间隔20
        let y = 20 + 10 * Math.random();//y轴方向位置为20-30随机
        let index = Math.floor(Math.random() * aCode.length);//随机索引值
        let txt = aCode[index];
        context.font = "bold 20px 微软雅黑";//设置或返回文本内容的当前字体属性
        context.fillStyle = getColor();//设置或返回用于填充绘画的颜色、渐变或模式，随机
        context.translate(x, y);//重新映射画布上的 (0,0) 位置，字母不可以旋转移动，所以移动容器
        let deg = 90 * Math.random() * Math.PI / 180;//0-90度随机旋转
        context.rotate(deg);// 	旋转当前绘图
        context.fillText(txt, 0, 0);//在画布上绘制“被填充的”文本
        context.rotate(-deg);//将画布旋转回初始状态
        context.translate(-x, -y);//将画布移动回初始状态
        arr[i] = txt //接收产生的随机数
    }
    num = arr[0] + arr[1] + arr[2] + arr[3] //将产生的验证码放入num
    // 绘制干扰线条
    for (let i = 0; i < 8; i++) {
        context.beginPath();//起始一条路径，或重置当前路径
        context.moveTo(Math.random() * 120, Math.random() * 40);//把路径移动到画布中的随机点，不创建线条
        context.lineTo(Math.random() * 120, Math.random() * 40);//添加一个新点，然后在画布中创建从该点到最后指定点的线条
        context.strokeStyle = getColor();//随机线条颜色
        context.stroke();// 	绘制已定义的路径
    }
    // 绘制干扰点，和上述步骤一样，此处用长度为1的线代替点
    for (let i = 0; i < 20; i++) {
        context.beginPath();
        let x = Math.random() * 120;
        let y = Math.random() * 40;
        context.moveTo(x, y);
        context.lineTo(x + 1, y + 1);
        context.strokeStyle = getColor();
        context.stroke();
    }
}

function codeSubmit() {
    let text = codeInput.value;
    codeInput.value = "";
    let password = passwordInput.value.trim();
    let username = usernameInput.value.trim();
    username = parseParams(username)
    password = parseParams(password)
    if (text === num) {
        form.submit();
    } else {
        canvas.click();
        showNum();
        alertError("Validation Code is error.", null);
        cutAct('focus')
    }
}


