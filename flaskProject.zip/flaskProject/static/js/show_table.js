let msgList = Array.from(document.querySelector(".msg").children).map(msg => msg.innerHTML);
let [pageNum, itemNum, totalNum, username] = msgList;
console.log(pageNum, itemNum, totalNum);
let selectPage = document.querySelector(".bottom select");
selectPage.value = itemNum;
let pagination = document.querySelector(".pagination");
let aLink = document.createElement("a");
let optionValues = document.querySelectorAll("option");
let backToHomeToggle = document.querySelector(".backToHome");
let backBtn = document.getElementById("arrow-back");
let forwardBtn = document.getElementById("arrow-forward");
let searchInput = document.getElementById("searchPerson");
let searchBtn = document.querySelector(".searchBtn");


searchBtn.onclick = () => {
  let searchKey = searchInput.value;
  // location.href = 
}

function clearStyle() {
  let aLinks = document.querySelectorAll("a.item");
  Array.from(aLinks).forEach((aLink) => aLink.classList.remove("active"));
}

function changeLink(type) {
  let aLinks = document.querySelectorAll("a.item");
  let index = 0;
  let selectValue = selectPage.value;
  for (let i = 0; i < aLinks.length; ++i) {
    let prevLink = i ? aLinks[i - 1] : null;
    let nextLink = i !== aLinks.length - 1 ? aLinks[i + 1] : null
    if (aLinks[i].classList.contains("active")) {
      index = i + 1;
      aLinks[i].classList.remove("active");
      console.log(prevLink);
      index = type === "back" ? (prevLink ? index - 1 : index) : (nextLink ? index + 1 : index);
      location.href = `/${parseParams(username)}/show/${selectValue}/${index}`;
      return;
    }
  };
}

//向前向后
backBtn.onclick = () => changeLink("back");
forwardBtn.onclick = () => changeLink("forward");


for (let i = 0; i < totalNum / itemNum; ++i) {
  let page = aLink.cloneNode(true);
  page.className = i + 1 === parseInt(pageNum) ? "item active" : "item";
  page.innerText = i + 1;
  pagination.appendChild(page);
  page.addEventListener("click", () => {
    clearStyle();
    page.classList.add("active");
    let selectValue = selectPage.value;
    location.href = `/${parseParams(username)}/show/${selectValue}/${page.innerText}`;
  });
}

//判断特殊情况
if (pageNum > totalNum / itemNum) {
  pageNum;
}

backToHomeToggle.onclick = () => location.href = `/${parseParams(username)}`;

selectPage.addEventListener("change", () => {
  let selectValue = selectPage.value;
  let aLinks = document.querySelectorAll("a.item");
  let targetNum = 0;
  Array.from(aLinks).forEach((aLink) => {
    if (aLink.classList.contains("active"))
      targetNum = aLink.innerText;
  });
  console.log(targetNum);
  if (totalNum < selectValue * (targetNum - 1))
    targetNum = 1;
  console.log(targetNum);
  location.href = `/${parseParams(username)}/show/${selectValue}/${targetNum}`;
});
