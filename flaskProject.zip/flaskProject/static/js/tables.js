function deleteSelected() {
    let checkboxes = Array.from(document.getElementsByName("selected_ids"));
    let selectedItems = checkboxes.filter(checkbox => checkbox.checked).map(checkbox => checkbox.value);
    if (selectedItems.length > 0) {
        alertConfirm('确定删除选中的项目吗？', () => {
            fetch(`/delete_selected/${selectedItems.join(",")}`)
                .then(response => {
                    if (response.ok) {
                        alertSuccess("删除成功！", () => {
                            location.reload();
                        });
                    } else
                        alertError("删除失败，请重试！");
                })
                .catch(error => {
                    alertError("请求发送失败：" + error);
                });
        });
    } else
        alertError("请选择要删除的项目！");
}