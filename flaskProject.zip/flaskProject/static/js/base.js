let menuToggle = document.querySelector(".menuToggle");
let slideBar = document.querySelector(".slidebar");
let bgChangeToggle = document.querySelector(".toggle-btn");
let logo = document.querySelector(".logo");
let selectionLis = document.querySelectorAll("ul li");
let myTables = document.querySelectorAll(".myTable");
let logoutBtn = document.getElementById("logout");
let personInfo = document.querySelector(".personInfo");
let horizontalBar = document.querySelector(".horizontalBar");
let bakcToTopToggle = document.querySelector(".backToTop");
let lockIcon = document.querySelector(".toggle-btn .icon ion-icon");
let changePasswd = document.getElementById("changePasswd");
let content = document.querySelector(".content");
let usernameMg = document.querySelector(".personInfo .text").innerText;
var elements = document.querySelectorAll('*');

function disableTransitions() {

}
function enableTransitions() {
    var elements = document.querySelectorAll('*');

}

document.addEventListener("DOMContentLoaded", () => {
    let state = localStorage.getItem("theme")
    let toggleStatus = localStorage.getItem("toggleStatus")

    for (var i = 0; i < elements.length; i++)
        elements[i].classList.add('no-transition');
    if (state != "night")
        bgChangeToggle.click()
    if (toggleStatus != "no")
        menuToggle.click()



});
//修改密码
changePasswd.onclick = () => {
    location.href = "/revise";
};

//监听滚动，展示阴影
content.onscroll = () => {
    horizontalBar.style.boxShadow = content.scrollTop ?
        slideBar.classList.contains("night") ? "0 16px 32px -16px rgba(255, 255, 255, 0.25), 0 0 0 1px rgba(255, 255, 255, 0.3)" : "0 16px 32px -16px rgba(0,0,0,.1), 0 0 0 1px rgba(0,0,0,.1)"
        : "";
}

bakcToTopToggle.onclick = (e) => {
    content.scrollTo({
        top: 0,
        behavior: "smooth"
    });
}

//拖拽按钮
menuToggle.addEventListener("mousedown", startDrag);

function startDrag(e) {
    e.preventDefault();

    let { width, height } = menuToggle.style;
    width = width.substring(0, width.indexOf("px"));
    height = height.substring(0, height.indexOf("px"));
    let { left, top } = menuToggle.getBoundingClientRect();
    let offsetX = e.clientX - left; //偏移
    let offsetY = e.clientY - top;

    function doDrag(e) {
        let x = e.clientX - offsetX;
        let y = e.clientY - offsetY;
        let { innerWidth: outerWidth, innerHeight: outerHeight } = window;
        menuToggle.style.left = x <= 0 ? "0px" : x >= outerWidth - width ? (outerWidth - width) + "px" : (x + "px");
        menuToggle.style.top = y <= 0 ? "0px" : y >= outerHeight - height ? (outerHeight - height) + "px" : (y + "px");
    }

    function stopDrag() {
        document.removeEventListener("mousemove", doDrag);
        document.removeEventListener("mouseup", stopDrag);
    }

    document.addEventListener("mousemove", doDrag);
    document.addEventListener("mouseup", stopDrag);
}

//退出登录
logoutBtn.onclick = () => {
    location.href = "/logout";
}

//切换侧边栏
menuToggle.onclick = () => {
    const toggleStatus = menuToggle.classList.contains("active") ? 'yes' : 'no';
    localStorage.setItem('toggleStatus', toggleStatus);
    menuToggle.classList.toggle("active");
    slideBar.classList.toggle("active");
};

//背景切换
bgChangeToggle.addEventListener("click", () => {
    bgChangeToggle.classList.toggle("active");
    // localStorage.setItem("bg", bgChangeToggle.classList.contains("active"));
    //console.dir(lockIcon);
    const selectedTheme = bgChangeToggle.classList.contains("active") ? 'night' : 'light';
    localStorage.setItem('theme', selectedTheme);
    document.body.classList.toggle("night");
    if (bgChangeToggle.classList.contains("active")) {
        lockIcon.setAttribute("name", "moon-outline");
        document.body.style.background = "#22242e";
    } else {
        lockIcon.setAttribute("name", "sunny-outline");
        document.body.style.background = "#fff";
    }
});

myTables.forEach(tableLink => tableLink.addEventListener("click", () => {
    location.href = tableLink.id === "add" ? `/${tableLink.id}/` : tableLink.id === "show" ? `/${tableLink.id}/10/1/_see` : `/${tableLink.id}/10/1`;
}));


//初始化更新页面细节部分
window.addEventListener("load", function () {
    for (var i = 0; i < elements.length; i++)
        elements[i].classList.remove('no-transition');
    // const elements = document.querySelectorAll("*");
    // elements.forEach(function (element) {
    //     element.style.transition = "none";
    // });
    // console.log("浏览器内部有无该属性");
    // bgChangeToggle.classList[`${localStorage.getItem("bg") ? "add" : "remove"}`]("active");
    let url = location.href;
    for (let i = 0; i < myTables.length; ++i) {
        if (url.includes("update")) {
            document.getElementById("show").classList.add("active"); 
            document.documentElement.style.setProperty(
                "--common-clr",
                myTables[i].style.getPropertyValue("--bg")
            );
            return;
        }
        if (url.includes(`/${myTables[i].id}`)) {
            document.getElementById(myTables[i].id).classList.add("active");
            document.documentElement.style.setProperty(
                "--common-clr",
                myTables[i].style.getPropertyValue("--bg")
            );
            return;
        }
    }
    document.getElementById("home").classList.add("active");
});