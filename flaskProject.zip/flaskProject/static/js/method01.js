let prov = document.getElementById('prov');
let city = document.getElementById('city');
let country = document.getElementById('country');
let curPorIndex;

/*自动加载省份列表*/
function showProv() {
    let len = province.length;
    for (let i = 0; i < len; i++) {
        let provOpt = document.createElement('option');
        provOpt.value = provOpt.innerText = province[i]['name'];
        prov.appendChild(provOpt);
    }
};
showProv()

/*根据所选的省份来显示城市列表*/
function showCity(obj) {
    let val = obj.options[obj.selectedIndex].value;
    city.length = 1;
    country.length = 1;
    if (val) {
        let len = province.length;
        let provIndex = 0;
        for (let i = 0; i < len; i++) {
            if (val == province[i]['name']) {
                provIndex = i;
            }
        }

        curPorIndex = provIndex;

        let cityLen = province[provIndex]["city"].length;
        for (let j = 0; j < cityLen; j++) {
            let cityOpt = document.createElement('option');
            cityOpt.value = cityOpt.innerText = province[provIndex]["city"][j].name;
            city.appendChild(cityOpt);
        }

        if (provIndex >= 0 && provIndex <= 6) {
            city.style.display = "none";
            city.selectedIndex = 1;
            showCountry(city);
        }
    }
}

/*根据所选的城市来显示县区列表*/
function showCountry(obj) {
    let val = obj.options[obj.selectedIndex].value;
    country.length = 1;
    let cityLen = province[curPorIndex]["city"].length;
    let cityIndex = 0;
    for (let i = 0; i < cityLen; i++) {
        if (city.value == province[curPorIndex]["city"][i].name) {
            cityIndex = i;
            break;
        }
    }

    if (val != '') {
        let countryLen = province[curPorIndex]["city"][cityIndex].districtAndCounty.length;
        for (let n = 0; n < countryLen; n++) {
            let countryOpt = document.createElement('option');
            countryOpt.innerText = province[curPorIndex]["city"][cityIndex].districtAndCounty[n];
            countryOpt.value = province[curPorIndex]["city"][cityIndex].districtAndCounty[n];
            country.appendChild(countryOpt);
        }
    }
}

/*点击确定按钮显示用户所选的地址*/
// function showAddr() {
//     if (curPorIndex >= 0 && curPorIndex <= 6)
//         userOrigin.value = prov.value + country.value;
//     else
//         userOrigin.value = prov.value + city.value + country.value;
// }