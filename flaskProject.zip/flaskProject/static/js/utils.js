function alertConfirm(title, callback) {
    Swal.fire({
        title: title,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: '确定',
        cancelButtonText: '取消'
    }).then((result) => {
        if (result.isConfirmed)
            callback && callback();
    });
}
function alertError(msg, callback, timerStatus = 1800) {
    Swal.fire({
        toast: true,
        icon: 'error',
        title: msg,
        showCancelButton: false,
        showConfirmButton: false,
        buttons: false,
        timer: timerStatus
    }).then((result) => {
        callback && callback();
    });
}

function alertSuccess(msg, callback, timerStatus = 1800) {
    Swal.fire({
        toast: true,
        icon: 'success',
        title: msg,
        showCancelButton: false,
        showConfirmButton: false,
        buttons: false,
        timer: timerStatus,
    }).then((result) => {
        callback && callback();
    });
}

function parseParams(obj) {
    let formatObj = obj.replace(/\%/g, "%25")
    formatObj = formatObj.replace(/\#/g, "%23")
    formatObj = formatObj.replace(/\&/g, "%26")
    formatObj = formatObj.replace(/\?/g, "%3F")
    return formatObj;
}

function deleteSelected() {
    let checkboxes = Array.from(document.getElementsByName("selected_ids"));
    let selectedItems = checkboxes.filter(checkbox => checkbox.checked).map(checkbox => checkbox.value);
    if (selectedItems.length > 0) {
        alertConfirm('确定删除选中的项目吗？', () => {
            fetch(`/delete_selected/${selectedItems.join(",")}`)
                .then(response => {
                    if (response.ok) {
                        alertSuccess("删除成功！", () => {
                            location.reload();
                        });
                    } else
                        alertError("删除失败，请重试！");
                })
                .catch(error => {
                    alertError("请求发送失败：" + error);
                });
        });
    } else
        alertError("请选择要删除的项目！");
}