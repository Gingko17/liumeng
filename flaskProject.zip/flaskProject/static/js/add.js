// let dd = document.querySelector(".item").innerText
//     if (action === "add") {
//         document.title = "更改数据";
//         let form = document.getElementById("form");
//         let data = JSON.parse('{{ data| safe }}');
//         Object.keys(data).forEach(key => {
//             form[key].value = data[key];
//             if (key === "stu_id")
//                 form[key].readOnly = true;
//             if (key === "stu_sex") {
//                 document.querySelectorAll('input[name="stu_sex"]').forEach(radio => {
//                     if (radio.value === data[key])
//                         radio.checked = true;
//                 });
//             }
//         });
//     }
let bar = document.querySelector(".bar");
let inputs = document.querySelectorAll(".formRow :is(input[type='text'], input[type='number'])")
let rows = document.querySelectorAll(".formRow :is(input,select)")
let useridInput = document.getElementById("userId");
let usernameInput = document.getElementById("userName");
let userSex = document.querySelectorAll("input[type='radio']");
let userAgeInput = document.getElementById("userAge");
let userPro = document.getElementById("userProfession");
// let userOriginInput = document.getElementById("userOrigin");
let userProfession = document.getElementById("userProfession");
let data = Array.from(document.querySelectorAll(".item"));
let submitBtn = document.getElementById("submitData");
let resetBtn = document.getElementById("resetData");
let addForm = document.getElementById("form");

function calcBar() {
    let ret = 0;
    if (useridInput.value.trim())
        ret += 1;
    if (usernameInput.value.trim())
        ret += 1;
    if (Array.from(userSex).filter(item => item.checked === true).length !== 0)
        ret += 1;
    if (userAgeInput.value.trim())
        ret += 1;
    if (prov.value && city.value && country.value)
        ret += 1;
    if (userPro.value)
        ret += 1;
    return ret;
}

rows.forEach(row => {
    row.addEventListener("change", () => {
        let process = calcBar();
        bar.style.width = process / 6 * 100 + "%";
    });
});

inputs.forEach(input => {
    let span = input.nextElementSibling;
    input.addEventListener("focus", () => {
        span.classList.add("active");
        input.classList.add("active");

    });
    input.addEventListener("blur", () => {
        if (!input.value) {
            span.classList.remove("active");
            input.classList.remove("active");
        }

    });
});

submitBtn.onclick = (e) => {
    e.preventDefault();
    if (!useridInput.value.trim()) {
        alertError("请输入学生学号！", null);
        useridInput.focus();
        return;
    }
    if (!usernameInput.value.trim()) {
        alertError("请输入学生姓名！", null);
        usernameInput.focus();
        return;
    }
    if (Array.from(userSex).filter(item => item.checked === true).length === 0) {
        alertError("请选择学生性别！", null);
        return;
    }
    if (!userAgeInput.value.trim()) {
        alertError("请输入学生年龄！", null);
        userAgeInput.focus();
        return;
    }
    if (parseInt(userAgeInput.value) > 22 || parseInt(userAgeInput.value) < 18) {
        alertError("学生年龄必须为18~22之间", null);
        userAgeInput.focus();
        return;
    }
    if (!(prov.value && city.value && country.value)) {
        alertError("请选择学生籍贯！", null);
        return;
    }
    if (!userPro.value) {
        alertError("请选择学生专业！", null);
        return;
    }
    addForm.submit();
}
resetBtn.onclick = () => {
    inputs.forEach(input => {
        let span = input.nextElementSibling;
        span.classList.remove("active");
        input.classList.remove("active");
    });
    bar.style.width = 0;
}
window.onload = () => {
    let msg = data[8].innerText;
    if (msg !== "添加成功" && msg) {
        alertError(msg, null);
        useridInput.value = data[0].innerText;
        usernameInput.value = data[1].innerText;
        userSex.forEach(sex => sex.value === data[2].innerText ? sex.checked = "true" : undefined);
        userAgeInput.value = data[3].innerText;

        inputs.forEach(input => {
            if (input.value) {
                let span = input.nextElementSibling;
                span.classList.add("active");
                input.classList.add("active");
            }
        });
        userProfession.value = data[7].innerText;
        let provIndex = province.findIndex(item => item["name"] === data[4].innerText);
        prov.selectedIndex = provIndex + 1;
        prov.onchange();
        // prov.value = data[4].innerText;
        // province[provIndex]
        city.value = data[5].innerText;
        city.onchange();
        country.value = data[6].innerText;
        userProfession.value = data[7].innerText;

        let process = calcBar();
        bar.style.width = process / 6 * 100 + "%";

    }
    else if (!msg) return;
    else
        alertSuccess(msg, () => {
            location.href = '/show/10/1/_see'
        })
}
